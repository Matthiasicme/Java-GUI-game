package codes;

public class Main {
        /**
         * @author Matthias Nawrocki
         * zawiera instancję Menu
         * @param args -
         */
        public static void main(String[] args) {

                Menu Menu = new Menu();
        }
}
